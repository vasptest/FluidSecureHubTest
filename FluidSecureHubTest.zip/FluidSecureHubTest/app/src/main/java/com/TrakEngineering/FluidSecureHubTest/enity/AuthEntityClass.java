package com.TrakEngineering.FluidSecureHubTest.enity;

/**
 * Created by Administrator on 6/2/2016.
 */
public class AuthEntityClass {

    public String IMEIUDID;
    public String VehicleNumber;
    public String FOBNumber;
    public int OdoMeter;
    public String ErrorCode;
    public int Hours;
    public String WifiSSId;
    public int SiteId;
    public String DepartmentNumber;
    public String PersonnelPIN;
    public String Other;
    public String RequestFrom;
    public String CurrentLat;
    public String CurrentLng;
    public String AppInfo;
    public String RequestFromAPP;
    public String IsVehicleNumberRequire;
    public String HubId;

    public String TransactionId;
    public String Status;

}
