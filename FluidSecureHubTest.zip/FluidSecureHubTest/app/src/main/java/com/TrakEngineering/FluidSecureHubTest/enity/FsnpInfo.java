package com.TrakEngineering.FluidSecureHubTest.enity;

public class FsnpInfo {

    public String Email;
    public String IMEI_UDID;
    public String transactionDate;
    public String TransactionFrom;
    public String CurrentLat;
    public String CurrentLng;
    public String VehicleRecurringMSG;

    public String FSTagMacAddress;
    public String FSNPMacAddress;


    public String VehicleId;
    public String Odometer;


}
