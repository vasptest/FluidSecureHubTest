package com.TrakEngineering.FluidSecureHubTest.enity;

/**
 * Created by User on 12/4/2017.
 */

public class CheckPinFobEntity {

    public String IMEIUDID;
    public String PersonPIN;
    public String PersonFOBNumber;
    public String FromNewFOBChange;
    public String IsBothFobAndPinRequired;

    public String HFVersion;
    public String LFVersion;
}
