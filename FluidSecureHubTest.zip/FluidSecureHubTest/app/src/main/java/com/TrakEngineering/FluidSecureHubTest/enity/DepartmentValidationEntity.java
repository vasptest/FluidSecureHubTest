package com.TrakEngineering.FluidSecureHubTest.enity;

public class DepartmentValidationEntity {

    public String IMEIUDID;
    public String DepartmentNumber;
    public String PersonnelPIN;
    public String RequestFromAPP;
}