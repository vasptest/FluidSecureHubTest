package com.TrakEngineering.FluidSecureHubTest.enity;

/**
 * Created by Administrator on 6/2/2016.
 *
 * {"Email":"subhashgaikwad4@gmail.com","PhoneNumber":"9730718842","PersonName":"subhash","IsApproved":"True","IMEI_UDID":"866376021415382"}
 */
public class UserInfoEntity {

    public String Email;
    public String PhoneNumber;
    public String PersonName;
    public String FluidSecureSiteName;
    public String IsApproved;
    public String IMEI_UDID;
    transient public String PersonEmail;

}
