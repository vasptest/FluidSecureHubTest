package com.TrakEngineering.FluidSecureHubTest.enity;

/**
 * Created by Administrator on 6/2/2016.
 */
public class VehicleRequireEntity {

    public String IMEIUDID;
    public String VehicleNumber;
    public String WifiSSId;
    public int SiteId;
    public String PersonnelPIN;
    public String RequestFromAPP;
    public String FOBNumber;
    public String FOBNumberPin;
    public String FromNewFOBChange;
    public String IsVehicleNumberRequire;
    public String Barcode;

    public String HFVersion;
    public String LFVersion;


}
