package com.TrakEngineering.FluidSecureHubTest.enity;

/**
 * Created by Administrator on 6/2/2016.
 */
public class UpgradeVersionEntity {


    public String HoseId;
    public String Version;
    public String Email;
    public String IMEIUDID;

    public String FSTagMacAddress;


}
