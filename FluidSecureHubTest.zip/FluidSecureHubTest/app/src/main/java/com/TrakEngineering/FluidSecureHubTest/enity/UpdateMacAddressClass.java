package com.TrakEngineering.FluidSecureHubTest.enity;

/**
 * Created by VASP on 9/4/2017.
 */

public class UpdateMacAddressClass {

    public String IMEIUDID;
    public int SiteId;
    public String MACAddress;
    public String RequestFrom;
    public String HubName;
}
