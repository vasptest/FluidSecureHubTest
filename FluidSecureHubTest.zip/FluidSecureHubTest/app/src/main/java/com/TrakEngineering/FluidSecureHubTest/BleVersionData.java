package com.TrakEngineering.FluidSecureHubTest;

public class BleVersionData {
    public String BLEType;
    public String VersionLF;
    public String VersionHF;
    public String PersonId;

}
