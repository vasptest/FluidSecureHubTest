package com.TrakEngineering.FluidSecureHubTest.offline;

public class EntityOffTranz {
    public String Id;
    public String HubId;
    public String SiteId;
    public String VehicleId;
    public String CurrentOdometer;
    public String CurrentHours;
    public String PersonId;
    public String FuelQuantity;
    public String TransactionDateTime;
    public String AppInfo;
    public String Pulses;
    public String TransactionFrom;
    public String PersonPin;
    public String OnlineTransactionId;
}
