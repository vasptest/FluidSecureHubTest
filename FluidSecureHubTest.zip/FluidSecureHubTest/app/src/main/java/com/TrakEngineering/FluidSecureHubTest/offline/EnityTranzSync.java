package com.TrakEngineering.FluidSecureHubTest.offline;

import java.util.ArrayList;

public class EnityTranzSync {

    ArrayList<EntityOffTranz> TransactionsModelsObj;
}
