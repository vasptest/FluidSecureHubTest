package com.TrakEngineering.FluidSecureHubTest.enity;

public class StatusForUpgradeVersionEntity {

    public String PersonId;
    public String HoseId;
    public String Email;
    public String IMEIUDID;

    public String HubName;
    public String SiteName;


}
