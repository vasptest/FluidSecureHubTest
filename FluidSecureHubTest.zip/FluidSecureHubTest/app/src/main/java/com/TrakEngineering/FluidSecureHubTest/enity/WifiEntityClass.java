package com.TrakEngineering.FluidSecureHubTest.enity;

/**
 * Created by intel on 4/15/2016.
 */
public class WifiEntityClass {

    public String ssidName;
    public String wifiIpAddress;
    public String connectionStatus;

}

