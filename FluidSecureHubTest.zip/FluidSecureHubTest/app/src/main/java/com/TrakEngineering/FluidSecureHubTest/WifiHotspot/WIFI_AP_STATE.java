package com.TrakEngineering.FluidSecureHubTest.WifiHotspot;

/**
 * Created by VASP on 9/1/2017.
 */


public enum WIFI_AP_STATE {
    WIFI_AP_STATE_DISABLING, WIFI_AP_STATE_DISABLED, WIFI_AP_STATE_ENABLING, WIFI_AP_STATE_ENABLED, WIFI_AP_STATE_FAILED
}