package com.TrakEngineering.FluidSecureHubTest.offline;

public class EntityFuelLimit {

    public String vehicleId;
    public String vehicleFuelLimitPerTxn;
    public String vehicleFuelLimitPerDay;
    public String personId;
    public String personFuelLimitPerTxn;
    public String personFuelLimitPerDay;
}
