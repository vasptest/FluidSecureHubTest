package com.TrakEngineering.FluidSecureHubTest.enity;

/**
 * Created by User on 10/27/2017.
 */

public class UpdateTransactionStatusClass {

    public String TransactionId;
    public String Status;
    public String AppInfo;
    public String IMEIUDID;

    public String CurrentLat;
    public String CurrentLng;
}
