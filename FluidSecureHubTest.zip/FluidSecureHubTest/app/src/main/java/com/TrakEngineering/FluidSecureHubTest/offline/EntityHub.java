package com.TrakEngineering.FluidSecureHubTest.offline;

public class EntityHub {

    public String HubId,AllowedLinks, PersonnelPINNumberRequired, VehicleNumberRequired, PersonhasFOB, VehiclehasFOB, WiFiChannel;
    public String BluetoothCardReader, BluetoothCardReaderMacAddress, LFBluetoothCardReader, LFBluetoothCardReaderMacAddress;
    public String PrinterMacAddress, PrinterName, EnablePrinter;
}
