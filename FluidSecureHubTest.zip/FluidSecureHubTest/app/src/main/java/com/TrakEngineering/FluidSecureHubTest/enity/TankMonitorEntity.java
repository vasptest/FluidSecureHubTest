package com.TrakEngineering.FluidSecureHubTest.enity;

public class TankMonitorEntity {


    public String IMEI_UDID;
    public int FromSiteId;
    public String ProbeReading;
    public String ReadingDateTime;
    public String Level;
    public String FromDirectTLD;
    public String Response_code;
    public String TLDTemperature;
    public String TLD;
    public String LSB;
    public String MSB;
    public String FOBNumberPin;


}
