package com.TrakEngineering.FluidSecureHubTest.enity;

/**
 * Created by Administrator on 1/18/2017.
 */

public class RenameHose {

    public String SiteId;
    public String HoseId;
    public String IsHoseNameReplaced;

}
