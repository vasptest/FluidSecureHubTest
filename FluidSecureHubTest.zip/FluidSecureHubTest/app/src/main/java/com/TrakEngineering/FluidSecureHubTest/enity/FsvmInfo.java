package com.TrakEngineering.FluidSecureHubTest.enity;

public class FsvmInfo {


    public String Email;
    public String IMEIUDID;
    public String transactionDate;
    public String TransactionFrom;
    public String CurrentLat;
    public String CurrentLng;
    public String VehicleRecurringMSG;
    public String FSTagMacAddress;
    public String CurrentFSVMFirmwareVersion;

    public String FSVM;
    public String ESP32_update;
    public String PIC_update;



    public String VIN;
    public String ODOK;

}
